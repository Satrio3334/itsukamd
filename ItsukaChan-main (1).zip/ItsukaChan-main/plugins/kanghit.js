import axios from 'axios'

async function apivisit() {
axios.get(`https://api.countapi.xyz/hit/ItsukaChan/visits`);
axios.get(`https://api.countapi.xyz/hit/ItsukaChan/visits`);
}
	// By Chandra XD
	// Follow bang
	// TikTok : @pnggilajacn
	// Github : https://github.com/Chandra-XD
export { 
    apivisit 
}